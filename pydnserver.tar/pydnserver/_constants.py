# encoding: utf-8

START_SERVERS = u'Start DNS Server'
STOP_SERVERS = u'Stop DNS Server'
