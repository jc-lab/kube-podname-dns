import DNSServer from pydnserver

print("OK")
